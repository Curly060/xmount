========================================================================
    DYNAMIC LINK LIBRARY : X-Ways AFF4 Plugin
========================================================================

This project contains the AFF4 reader Plugin for X-Ways.