These are the tests for the mKR (my Knowledge Representation) Language
that must be passed by conformant systems.  See
  http://mkrmke.org/parser/
for the full conformance information.

The format is a set of exact serialization format tests.

Tests are a pair of files:
  xxx.ttl xxx.mkr
which are the input Turtle file and the expected output mKR file.

Dick
